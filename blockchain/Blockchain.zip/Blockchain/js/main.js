const sha256 = require('/Users/sefx5/Desktop/Blockchain/node_modules/crypto-hash')

class Block{
    constructor(sender,receiver,deposit,total,timestamp,prevHash,hash){
        this.sender = sender
        this.receiver = receiver
        this.deposit = deposit
        this.total = total
        this.timestamp = timestamp
        this.prevHash = prevHash
        this.hash = hash
    }
}

class Blockchain{
    constructor(capacity=5){
        this.capacity = capacity
        this.data = [null] * capacity
        this.size = 0
    }

    async hash(hashData){
        return await this.MD5(hashData)
    }
}